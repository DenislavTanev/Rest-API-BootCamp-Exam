﻿namespace SoftUni_BootCamp.Models.InputModels
{
    public class SkillInputModel
    {
        public string Name { get; set; }
    }
}
