﻿namespace SoftUni_BootCamp.Models.InputModels
{
    public class RecruiterInputModel
    {
        public string LastName { get; set; }

        public string Email { get; set; }

        public string Country { get; set; }
    }
}
