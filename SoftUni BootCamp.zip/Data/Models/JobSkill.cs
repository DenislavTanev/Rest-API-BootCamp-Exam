﻿namespace SoftUni_BootCamp.Data.Models
{
    public class JobSkill
    {
        public string SkillId { get; set; }

        public Skill Skill { get; set; }

        public string JobId { get; set; }
    }
}
