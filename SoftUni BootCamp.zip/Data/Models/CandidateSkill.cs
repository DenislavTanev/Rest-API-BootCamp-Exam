﻿namespace SoftUni_BootCamp.Data.Models
{
    public class CandidateSkill
    {
        public string SkillId { get; set; }

        public Skill Skill { get; set; }

        public string CandidateId { get; set; }
    }
}
